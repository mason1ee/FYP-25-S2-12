console.log('external script ran');
