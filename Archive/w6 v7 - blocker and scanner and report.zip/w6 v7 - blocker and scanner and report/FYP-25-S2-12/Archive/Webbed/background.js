chrome.runtime.onInstalled.addListener(() => {
  console.log('Script Inspector extension installed');
});
