let lastSecurityHeaders = {};

chrome.runtime.onInstalled.addListener(() => {
  console.log('Script Inspector extension installed');
});

// Restore JS-Blocker state on startup
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get('blocked', ({ blocked }) => {
    if (typeof blocked === 'boolean') {
      chrome.declarativeNetRequest.updateEnabledRulesets(
        blocked
          ? { enableRulesetIds: ['ruleset_1'] }
          : { disableRulesetIds: ['ruleset_1'] }
      );
    }
  });
});

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    // Extract security headers from the response headers
    const headers = {};
    details.responseHeaders.forEach((header) => {
      headers[header.name.toLowerCase()] = header.value;
    });
    lastSecurityHeaders = headers;
  },
  { urls: ["http://*/*", "https://*/*"] },
  ["responseHeaders"]
);

// Listen for popup messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 1) Return the latest security headers if asked
  if (message.action === 'getSecurityHeaders') {
    sendResponse({ headers: lastSecurityHeaders });
  }

  // 2) Handle JS-Blocker on/off requests
  if (typeof message.setBlocked === 'boolean') {
    const newState = message.setBlocked;
    chrome.declarativeNetRequest.updateEnabledRulesets(
      newState
        ? { enableRulesetIds: ['ruleset_1'] }
        : { disableRulesetIds: ['ruleset_1'] },
      () => {
        chrome.storage.local.set({ blocked: newState }, () => {
          sendResponse({ blocked: newState });
        });
      }
    );
    return true; // keep sendResponse channel open
  }

  return false;
});