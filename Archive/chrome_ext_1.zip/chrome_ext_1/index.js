document.addEventListener("DOMContentLoaded", function () {
  // Scan logic
  const progressBar = document.getElementById("progress-bar");
  const statusText = document.getElementById("status-text");
  const resultText = document.getElementById("scan-result");
  const detailedResults = document.getElementById("detailed-results");
  document.getElementById("toggle-xss").checked = true;
  document.getElementById("toggle-lib").checked = true;

  let timeLeft = 5;
  let progress = 0;
  const threats = ["XSS", "Clickjacking", "Insecure Library"];

  // Start fake scan interval
  const interval = setInterval(() => {
    timeLeft--;
    progress += 20;
    progressBar.style.width = progress + "%";
    statusText.textContent = `Scan in progress... (${timeLeft}s)`;

    if (progress >= 100) {
      clearInterval(interval);
      statusText.textContent = "Scan complete";
      // Force result to be insecure every time
      const isSecure = false;
      resultText.textContent = "Website is insecure!";
      resultText.style.color = "red";
      // Randomise output
      //const isSecure = Math.random() > 0.5;
      //resultText.textContent = isSecure ? "Website is secure!" : "Website is insecure!";
      //resultText.style.color = isSecure ? "green" : "red";

      // Add fake insecure results
      detailedResults.innerHTML = "";
      
      // Choose 1–3 random threats to display
      //if (!isSecure) {
        let threatCount = Math.floor(Math.random() * 2) + 1;
        for (let i = 0; i < threatCount; i++) {
          let threat = threats[Math.floor(Math.random() * threats.length)];
          const li = document.createElement("li");
          li.textContent = `Threat detected: ${threat}`;
          detailedResults.appendChild(li);
        //}
      }
    }
  }, 1000);

  // Top tabs
  const scanTabBtn = document.getElementById("scan-tab-btn");
  const settingsTabBtn = document.getElementById("settings-tab-btn");
  const scanTab = document.getElementById("scan-tab");
  const settingsTab = document.getElementById("settings-tab");

  scanTabBtn.addEventListener("click", () => {
    scanTab.style.display = "block";
    settingsTab.style.display = "none";
    scanTabBtn.classList.add("active");
    settingsTabBtn.classList.remove("active");
  });

  settingsTabBtn.addEventListener("click", () => {
    scanTab.style.display = "none";
    settingsTab.style.display = "block";
    scanTabBtn.classList.remove("active");
    settingsTabBtn.classList.add("active");
  });

  // Inner Settings tab logic
  const toggleAdvanced = document.getElementById("toggle-advanced");
  const settingsSubTabBtn = document.getElementById("settings-sub-tab-btn");
  const additionalSubTabBtn = document.getElementById("additional-sub-tab-btn");
  const settingsSubTab = document.getElementById("settings-sub-tab");
  const additionalSubTab = document.getElementById("additional-sub-tab");

  function updateInnerTabs(state) {
    if (state) {
      additionalSubTabBtn.classList.remove("disabled");
    } else {
      additionalSubTabBtn.classList.add("disabled");
      additionalSubTab.style.display = "none";
      settingsSubTab.style.display = "block";
      settingsSubTabBtn.classList.add("active");
      additionalSubTabBtn.classList.remove("active");
    }
  }

  toggleAdvanced.addEventListener("change", function () {
    updateInnerTabs(toggleAdvanced.checked);
  });

  settingsSubTabBtn.addEventListener("click", () => {
    settingsSubTab.style.display = "block";
    additionalSubTab.style.display = "none";
    settingsSubTabBtn.classList.add("active");
    additionalSubTabBtn.classList.remove("active");
  });

  additionalSubTabBtn.addEventListener("click", () => {
    if (!additionalSubTabBtn.classList.contains("disabled")) {
      settingsSubTab.style.display = "none";
      additionalSubTab.style.display = "block";
      settingsSubTabBtn.classList.remove("active");
      additionalSubTabBtn.classList.add("active");
    }
  });
});
