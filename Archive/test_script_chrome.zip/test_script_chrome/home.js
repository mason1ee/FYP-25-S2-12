document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("clickme").addEventListener("click", moving_bar);

    let i = 0;
    function moving_bar() {
        if (i === 0) {
            i = 1;
            const elem = document.getElementById("loadingBar");
            let width = 1;
            const id = setInterval(frame, 10);
            function frame() {
                if (width >= 100) {
                    clearInterval(id);
                    i = 0;
                } else {
                    width++;
                    elem.style.width = width + "%";
                }
            }
        }
    }
});
