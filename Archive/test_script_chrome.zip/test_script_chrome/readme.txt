1. open chrome://extensions/
2. enable developer mode (top right hand corner)
3. puzzle piece at top right of url bar, click on that
4. click on the imported script
5. every time u edit the html/js/css/json files and save, have to go to extension settings to refresh

